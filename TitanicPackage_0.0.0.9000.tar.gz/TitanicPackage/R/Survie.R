
#'Calcul du taux de survie en fonction de la variable donnée en entrée
#'
#'@author Maroua 
#'@param data jeu de données
#'@param variable colonne données
#'
#'@examples
#'taux_survie(data,'passengerClass')
#'taux_survie(data, 'sex')
#'
#'@export


taux_survie <- function(data,variable) { 
  library(dplyr) 
  data %>% 
    group_by(data[,variable]) %>% 
    summarize(TauxSurvie = sum(survived == "yes") / n())}

